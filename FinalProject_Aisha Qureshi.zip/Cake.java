package FinalProject;

public class Cake {
    private String flavor;

    public Cake(String flavor) {
        this.flavor=flavor;
    }

    public String getFlavor(){
        return flavor;
    }

    public void setFloavor(String flavor) {
        this.flavor=flavor;
    }

    public String toString() {
        return "The cake is baking and it is " + flavor + ".";
    }

    public Cake () throws NoFlavorException {
        throw new NoFlavorException();
    }


}
