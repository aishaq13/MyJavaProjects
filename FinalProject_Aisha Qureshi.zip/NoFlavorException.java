package FinalProject;

public class NoFlavorException extends Exception {
    public NoFlavorException () {
        super ("Error: The cake must have a flavor. ");
    }
}
